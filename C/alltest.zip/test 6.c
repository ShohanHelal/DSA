#include<stdio.h>
int main(){
int n,t,i,j,k;
scanf("%d",&t);
for(k=0;k<=t;k++){
scanf("%d",&n);
for(i=0;i<=n;i++){
    for(j=0;j<=n;j++){
        if(i+j==n){
            printf("%d %d\n",i,j);
        }
else{
            break;
        }
    }
}
}
return 0;
}
