#include<stdio.h>
int main()
{
    int t,n,i;
    scanf("%d",&t);
    for(i=1; i<=t; i++)
    {
        scanf("%d",&n);
        {
            if(n%2==0)
            {
                printf("case %d:even\n",i);
            }
            else
            {
                printf("case %d:odd\n",i);
            }
        }
    }
    return 0;
}
