#include<stdio.h>
int max(int x)
{
    int i,ma=0,m;
    if(m>ma)
    {
        ma=m;
    }
    return ma;
}
int main()
{
    int t,n,m,i,mx;
    scanf("%d",&t);
    for(i=1; i<=t; i++)
    {
        scanf(" %d",&n);
        for(i=1; i<=n; i++)
        {
            scanf("%d",&m);
            mx=max(m);

        }
    }

printf("%d",mx);

return 0;
}
