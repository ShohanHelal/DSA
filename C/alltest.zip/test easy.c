#include<stdio.h>
int main(){
int a,b,t,i;
scanf("%d",&t);
for(i=1;i<=t;t++){
scanf("%d%d",&a,&b);
if(a>b){
    printf(">\n");
    break;
}
else if(a<b){
    printf("<\n");
    break;
}
else if(a==b){
    printf("=\n");
    break;
}
}
return 0;
}
