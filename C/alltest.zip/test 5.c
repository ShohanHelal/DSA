#include<stdio.h>
int fio(int x){
    int i,s=0;
 for(i=1; i<x; i++)
        {
            if(x%i==0)
            {
                s=s+i;
            }
        }
return s;
}
int main()
{
    int t,n,i,sum,j;
    scanf("%d",&t);
    for(j=0; j<=t; j++)
    {
        scanf("%d",&n);
       sum=fio(n);
        printf("%d\n",sum);

    }

    return 0;
}
